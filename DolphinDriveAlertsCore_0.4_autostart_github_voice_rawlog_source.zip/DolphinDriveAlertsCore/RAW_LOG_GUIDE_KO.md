# 실차 RAW 신호 자동 로그 수집

## 동작
- `DrivingAlertService` 시작과 동시에 자동 수집 시작.
- 핵심 신호는 150ms 폴링.
- 1초마다 전체 스냅샷 기록.
- 값이 바뀌면 다음 1초 스냅샷을 기다리지 않고 change 레코드 기록.
- 약 1.05초마다 BYD SDK의 parameter-free `get*` / `is*` 메서드를 read-only reflection으로 탐색하여 변경값 기록.
- setter, parameter가 필요한 메서드는 호출하지 않음.

## 수집 대상
기어, 속도, EPB, AVH/AutoHold 후보, BSD, 차선 오프셋, TJA/ICC 후보,
주행 인터페이스, 회생제동, 주행설정, deviation/PCW/lane-line 후보,
레이더 거리 배열, EnergyDevice의 recycle/roadSurface/operationMode/ACC 후보 및
BYD SDK에서 안전하게 읽을 수 있는 추가 getter 값.

## 파일 만들기
앱 화면에서 **수집된 파일 생성 · Download 폴더에 저장** 버튼을 누르면:

`Download/DolphinDriveAlerts_RAW_yyyyMMdd_HHmmss.zip`

형태로 생성된다.
ZIP 안에는 `logs/raw-*.jsonl`과 `device.json`이 들어간다.

## 실차 테스트 팁
원하는 동작 직전에 **현재 시점 마커 기록** 버튼을 누른 뒤 기능을 조작하면
JSONL의 `USER_MARKER` 이후 변경값을 비교하기 쉽다.
