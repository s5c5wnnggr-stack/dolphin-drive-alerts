# 차량 신호 연결 상태 — Core 0.1

| 기능 | 코어/음성 엔진 | 실제 차량 신호 자동 연결 | 현재 근거 |
|---|---|---|---|
| 기어 P/D/N/R | 완료 | 완료 | `getCurrentGear`, raw 0=N/1=R/2=D/3=P |
| EPB 체결/해제 | 완료 | 완료 | `getEPBState`, raw 1=해제/3=체결 |
| 회생 STANDARD/HIGH | 완료 | 참조 매핑 적용 | AutoFeedback 리소스 2=STANDARD/3=HIGH + BYD energy getter 후보 |
| Snow ON/OFF | 완료 | getter 존재 시 참조 매핑 | AutoFeedback road surface 1=COMMON/2=SNOW |
| SPORT | 완료 | getter 존재 시 SPORT ON 연결 | AutoFeedback operation mode 2=SPORT ON |
| ECO/NORMAL | 완료 | 캘리브레이션 대기 | SPORT OFF만으로 둘을 구분하지 않음 |
| AutoHold ON/OFF | 완료 | 캘리브레이션 대기 | `getAVHState` raw 변화 로깅 |
| AutoHold 체결/해제 | 완료 | 캘리브레이션 대기 | AVH 상태 의미 실차 매핑 필요 |
| ICC ON/OFF | 완료 | 캘리브레이션 대기 | TJA/ACC 계기판 후보 raw 매핑 필요 |
| BSD 위험 좌/우 | 완료 | 캘리브레이션 대기 | `getBSDState`는 기능 ON/OFF일 수 있어 위험 이벤트로 오용 금지 |
| 앞차 출발 | 완료 | 캘리브레이션 대기 | 레이더 거리 기반 엔진/순정 이벤트 중 실차 검증 후 선택 |
| 차선 이탈 좌/우 | 완료 | 캘리브레이션 대기 | `getDeviationState`, `getLaneOffsetState`, lane state raw 로깅 |
| 도어 열기 전 후측방 위험 | 완료 | 캘리브레이션 대기 | 도어/후측방 경고의 실제 raw 조합 1회 실차 캡처 필요 |

**원칙:** raw 의미가 확정되지 않은 상태를 억지로 ON/OFF로 추정해서 음성을 내지 않습니다.
코어에는 해당 이벤트와 좌/우 음성, 우선순위, 쿨다운, 테스트 재생까지 모두 들어 있고,
실차 로그에서 raw 전환이 잡히면 `VehicleEventDetector`의 매핑만 추가하면 됩니다.
