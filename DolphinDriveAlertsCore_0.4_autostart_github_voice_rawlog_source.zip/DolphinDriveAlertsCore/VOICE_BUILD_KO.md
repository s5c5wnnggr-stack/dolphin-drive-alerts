# 0.3 음성팩 / GitHub Actions 빌드

- 생성 엔진: `edge-tts 7.2.8`
- 여성: `ko-KR-SunHiNeural`
- 남성: `ko-KR-InJoonNeural`
- 결과: 남성 29 + 여성 29 = **58개 WAV**
- APK 내부 포맷: PCM signed 16-bit / mono / 44.1 kHz
- 실차 재생: 온라인 TTS 미사용. APK asset에서 즉시 읽어 `AudioTrack`으로 출력.
- 운전석 출력: 실차 확인된 BYD legacy stream 14 attributes, 실패 시 raw stream 14 fallback.
- 미디어 출력: `USAGE_MEDIA`.

GitHub의 **Actions -> Build Real-Car APK with Korean Voice Pack -> Run workflow**를 실행하면 음성 58개를 새로 만들고 설치 가능한 debug-signed APK와 생성 후 전체 소스 ZIP을 artifact로 올립니다.

산출물:
- `DolphinDriveAlerts-v0.3-realcar-voice-rawlog.apk`
- `DolphinDriveAlerts-v0.3-realcar-voice-rawlog.apk.sha256`
- `DolphinDriveAlerts-v0.3-generated-source.zip`
- `voice_pack_manifest.generated.json`
