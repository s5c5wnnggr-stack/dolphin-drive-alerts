PRE-RECORDED VOICE PACK
=======================
This app never relies on runtime TTS for driving alerts.
Place PCM WAV files in assets/voice/male and assets/voice/female.
Recommended: PCM signed 16-bit, mono, 44100 Hz.

Base filenames are lowercase AlertEvent names, for example:
  gear_p.wav                 -> 파킹
  gear_d.wav                 -> 전진
  regen_standard.wav         -> 회생제동 스탠다드
  drive_normal.wav           -> 주행모드 노멀
  autohold_engaged.wav       -> 오토홀드 체결
  lead_car_departure.wav     -> 앞차 출발

Side-aware warnings should include both base and side-specific files:
  bsd_warning.wav / bsd_warning_left.wav / bsd_warning_right.wav
  lane_departure.wav / lane_departure_left.wav / lane_departure_right.wav
  exit_rear_warning.wav / exit_rear_warning_left.wav / exit_rear_warning_right.wav

If a selected male/female asset is missing, the engine deliberately falls back
to a local effect sound rather than using a car TTS engine.
