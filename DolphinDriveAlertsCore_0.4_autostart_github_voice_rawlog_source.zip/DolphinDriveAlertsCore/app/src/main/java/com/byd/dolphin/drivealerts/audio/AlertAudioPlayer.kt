package com.byd.dolphin.drivealerts.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.AlertStyle
import com.byd.dolphin.drivealerts.model.OutputRoute
import com.byd.dolphin.drivealerts.util.CoreLog
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.PI
import kotlin.math.sin

class AlertAudioPlayer(private val context: Context) {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "drive-alert-audio") }
    private val sequence = AtomicLong()
    private val wavCache = HashMap<String, PcmWav>()

    fun play(request: AlertRequest) {
        val token = sequence.incrementAndGet()
        worker.execute {
            val style = AlertPreferences.style(context)
            val route = AlertPreferences.route(context)
            val voicePath = VoiceAssetCatalog.path(request, style)
            if (voicePath != null) {
                val wav = loadVoice(voicePath)
                if (wav != null) {
                    playPcm(wav, route, token, "voice:$voicePath")
                    return@execute
                }
                CoreLog.w("AUDIO", "voice asset missing: $voicePath; effect fallback phrase=${request.phrase}")
            }
            playEffect(request, route, token)
        }
    }

    fun shutdown() { worker.shutdownNow() }

    private fun loadVoice(path: String): PcmWav? = synchronized(wavCache) {
        wavCache[path]?.let { return it }
        val parsed = runCatching { PcmWavReader.read(context.assets.open(path)) }
            .onFailure { CoreLog.w("AUDIO", "failed to load $path: ${it.message}") }
            .getOrNull() ?: return null
        wavCache[path] = parsed
        parsed
    }

    private fun playEffect(request: AlertRequest, route: OutputRoute, token: Long) {
        val (freq, repeats, duration) = when {
            request.event.priority >= 90 -> Triple(1120.0, 3, 130)
            request.event.priority >= 70 -> Triple(930.0, 2, 150)
            request.event.name == "LEAD_CAR_DEPARTURE" -> Triple(660.0, 2, 110)
            else -> Triple(760.0, 1, 120)
        }
        repeat(repeats) { index ->
            if (sequence.get() != token) return
            val samples = tone(44_100, freq + index * 55.0, duration)
            playPcm(PcmWav(44_100, 1, 16, samples), route, token, "effect:${request.event}")
            if (index < repeats - 1) Thread.sleep(70)
        }
    }

    private fun tone(sampleRate: Int, hz: Double, ms: Int): ShortArray {
        val n = sampleRate * ms / 1000
        return ShortArray(n) { i ->
            val fade = minOf(1.0, i / 400.0, (n - i) / 400.0).coerceAtLeast(0.0)
            (sin(2.0 * PI * hz * i / sampleRate) * 0.28 * fade * Short.MAX_VALUE).toInt().toShort()
        }
    }

    private fun playPcm(wav: PcmWav, route: OutputRoute, token: Long, label: String) {
        val mono = if (wav.channels == 1) wav.pcm16 else downmix(wav.pcm16, wav.channels)
        val rate = wav.sampleRate.coerceIn(8_000, 96_000)
        if (sequence.get() != token) return
        val attrs = when (route) {
            OutputRoute.DRIVER_STREAM14 -> buildDriverStream14Attributes()
            OutputRoute.MEDIA -> AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        }
        try {
            playWithAttributes(mono, rate, attrs, token, "$label/$route")
        } catch (t: Throwable) {
            CoreLog.w("AUDIO", "attributes playback failed: ${t.message}", t)
            if (route == OutputRoute.DRIVER_STREAM14) playRawStream14(mono, rate, token, label)
        }
    }

    private fun playWithAttributes(samples: ShortArray, rate: Int, attrs: AudioAttributes, token: Long, label: String) {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(0)
        val track = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(maxOf(samples.size * 2, min))
            .build()
        try {
            val written = track.write(samples, 0, samples.size)
            require(written > 0) { "AudioTrack write=$written" }
            track.setVolume(0.88f)
            CoreLog.i("AUDIO", "play $label samples=$written rate=$rate session=${track.audioSessionId}")
            track.play()
            waitFor(samples.size, rate, token)
            runCatching { track.stop() }
        } finally { track.release() }
    }

    @Suppress("DEPRECATION")
    private fun playRawStream14(samples: ShortArray, rate: Int, token: Long, label: String) {
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(0)
        val track = AudioTrack(14, rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(samples.size * 2, min), AudioTrack.MODE_STATIC)
        try {
            val written = track.write(samples, 0, samples.size)
            require(track.state == AudioTrack.STATE_INITIALIZED) { "raw stream14 state=${track.state} write=$written" }
            track.setVolume(0.88f)
            CoreLog.i("AUDIO", "play raw stream14 $label samples=$written")
            track.play()
            waitFor(samples.size, rate, token)
            runCatching { track.stop() }
        } finally { track.release() }
    }

    private fun waitFor(samples: Int, rate: Int, token: Long) {
        val end = System.currentTimeMillis() + samples * 1000L / rate + 80L
        while (System.currentTimeMillis() < end && sequence.get() == token) Thread.sleep(20)
    }

    private fun buildDriverStream14Attributes(): AudioAttributes {
        val builder = AudioAttributes.Builder()
        val method = builder.javaClass.methods.firstOrNull { it.name == "setLegacyStreamType" && it.parameterTypes.size == 1 }
            ?: builder.javaClass.declaredMethods.firstOrNull { it.name == "setLegacyStreamType" && it.parameterTypes.size == 1 }
            ?: throw NoSuchMethodException("setLegacyStreamType")
        runCatching { method.isAccessible = true }
        method.invoke(builder, 14)
        return builder.build()
    }

    private fun downmix(input: ShortArray, channels: Int): ShortArray {
        if (channels <= 1) return input
        val frames = input.size / channels
        return ShortArray(frames) { f ->
            var sum = 0
            for (c in 0 until channels) sum += input[f * channels + c].toInt()
            (sum / channels).toShort()
        }
    }
}
