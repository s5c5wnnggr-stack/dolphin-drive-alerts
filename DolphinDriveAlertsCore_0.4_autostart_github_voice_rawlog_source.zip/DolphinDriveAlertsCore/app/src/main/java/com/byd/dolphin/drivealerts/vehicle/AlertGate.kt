package com.byd.dolphin.drivealerts.vehicle

import com.byd.dolphin.drivealerts.model.AlertRequest
import java.util.concurrent.ConcurrentHashMap

class AlertGate(private val deliver: (AlertRequest) -> Unit) {
    private val last = ConcurrentHashMap<String, Long>()
    fun submit(request: AlertRequest) {
        val key = "${request.event}:${request.side}"
        val now = System.currentTimeMillis()
        val before = last[key] ?: 0L
        if (now - before < request.event.cooldownMs) return
        last[key] = now
        deliver(request)
    }
}
