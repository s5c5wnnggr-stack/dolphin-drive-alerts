package com.byd.dolphin.drivealerts.dpi

import android.content.Context
import com.byd.dolphin.drivealerts.model.OutputRoute
import com.byd.dolphin.drivealerts.util.CoreLog

/**
 * Policy surface for external-app routing.
 * Public Android APIs cannot force another UID's playback onto BYD legacy stream 14.
 * Keep the user's per-app choice now, but do not fake a successful route until a
 * vehicle-specific vendor command/API is captured and verified.
 */
object ExternalAppAudioRouter {
    enum class Status { MEDIA_DEFAULT, DRIVER_ROUTE_PENDING_VENDOR_HOOK }

    fun apply(context: Context, packageName: String, route: OutputRoute): Status {
        return when (route) {
            OutputRoute.MEDIA -> Status.MEDIA_DEFAULT
            OutputRoute.DRIVER_STREAM14 -> {
                CoreLog.w("APP_AUDIO", "driver route requested for $packageName; BYD cross-UID vendor hook not verified")
                Status.DRIVER_ROUTE_PENDING_VENDOR_HOOK
            }
        }
    }
}
