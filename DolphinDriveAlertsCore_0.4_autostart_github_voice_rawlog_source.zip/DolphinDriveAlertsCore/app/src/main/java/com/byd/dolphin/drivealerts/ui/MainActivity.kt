package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import com.byd.dolphin.drivealerts.audio.VoiceAssetCatalog
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.model.*
import com.byd.dolphin.drivealerts.service.DrivingAlertService
import com.byd.dolphin.drivealerts.log.DiagnosticsExporter

class MainActivity : Activity() {
    private lateinit var eventSpinner: Spinner
    private lateinit var sideSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        DrivingAlertService.start(this)
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 24, 30, 30)
        }
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        box.addView(TextView(this).apply {
            text = "주행 보조 알림 · CORE 0.4 REAL-CAR AUTO-START + VOICE + RAWLOG"
            textSize = 24f; setTypeface(typeface, Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = "UI 완성 전 기능 검증 화면입니다. 알림 출력·신호 감시·앱별 DPI 정책만 먼저 구현합니다."
            textSize = 15f; setPadding(0, 8, 0, 20)
        })

        box.addView(section("알림 출력 경로"))
        val route = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val driver = RadioButton(this).apply { text = "운전석(stream 14)"; id = View.generateViewId() }
        val media = RadioButton(this).apply { text = "미디어"; id = View.generateViewId() }
        route.addView(driver); route.addView(media); box.addView(route)
        if (AlertPreferences.route(this) == OutputRoute.DRIVER_STREAM14) driver.isChecked = true else media.isChecked = true
        route.setOnCheckedChangeListener { _, id -> AlertPreferences.setRoute(this, if (id == driver.id) OutputRoute.DRIVER_STREAM14 else OutputRoute.MEDIA) }

        box.addView(section("알림 종류"))
        val style = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val male = RadioButton(this).apply { text = "남성"; id = View.generateViewId() }
        val female = RadioButton(this).apply { text = "여성"; id = View.generateViewId() }
        val effect = RadioButton(this).apply { text = "효과음"; id = View.generateViewId() }
        style.addView(male); style.addView(female); style.addView(effect); box.addView(style)
        when (AlertPreferences.style(this)) { AlertStyle.MALE -> male.isChecked=true; AlertStyle.FEMALE -> female.isChecked=true; AlertStyle.EFFECT -> effect.isChecked=true }
        style.setOnCheckedChangeListener { _, id ->
            AlertPreferences.setStyle(this, when(id){ male.id->AlertStyle.MALE; female.id->AlertStyle.FEMALE; else->AlertStyle.EFFECT })
        }
        box.addView(TextView(this).apply {
            text = "남/여 음성은 GitHub 빌드 시 Neural TTS로 새로 생성한 PCM WAV 58개를 APK에 내장해 즉시 재생합니다. 실차에서는 네트워크나 TTS 엔진이 필요하지 않습니다."
            textSize = 13f
        })

        box.addView(section("알림 테스트"))
        eventSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, AlertEvent.entries.map { "${it.name} · ${it.phrase}" }) }
        sideSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, Side.entries.map { it.name }) }
        box.addView(eventSpinner); box.addView(sideSpinner)
        box.addView(Button(this).apply {
            text = "선택 알림 즉시 재생"
            setOnClickListener {
                DrivingAlertService.test(this@MainActivity, AlertEvent.entries[eventSpinner.selectedItemPosition], Side.entries[sideSpinner.selectedItemPosition])
            }
        })

        box.addView(section("자동 실행 / 백그라운드"))
        box.addView(TextView(this).apply {
            text = "설치 후 최초 1회 앱을 실행하면 이후 일반 재부팅·차량 Quick Boot·앱 업데이트 후 foreground 서비스가 자동 시작됩니다. 화면을 닫거나 최근 앱에서 지워도 서비스는 계속 유지됩니다. Android 설정에서 강제 종료한 경우에는 Android 정책상 다시 한 번 앱을 직접 실행해야 합니다."
            textSize = 13f
        })

        box.addView(section("실차 RAW 신호 로그"))
        box.addView(TextView(this).apply {
            text = "앱 서비스가 실행되는 동안 차량 RAW 신호를 자동 수집합니다. 1초 주기 전체 스냅샷 + 값 변경 즉시 기록 + BYD read-only getter 자동 탐색을 함께 저장합니다."
            textSize = 13f
        })
        box.addView(Button(this).apply {
            text = "수집된 파일 생성 · Download 폴더에 저장"
            setOnClickListener {
                val logger = DrivingAlertService.activeLogger
                if (logger == null) {
                    DrivingAlertService.start(this@MainActivity)
                    Toast.makeText(this@MainActivity, "로그 서비스 시작 중입니다. 잠시 후 다시 눌러주세요.", Toast.LENGTH_LONG).show()
                } else {
                    logger.marker("USER_EXPORT_REQUEST")
                    isEnabled = false
                    Thread {
                        val result = DiagnosticsExporter.exportToDownloads(this@MainActivity, logger)
                        runOnUiThread {
                            isEnabled = true
                            Toast.makeText(this@MainActivity,
                                result.fold({ "생성 완료: $it" }, { "생성 실패: ${it.message}" }),
                                Toast.LENGTH_LONG).show()
                        }
                    }.start()
                }
            }
        })
        box.addView(Button(this).apply {
            text = "현재 시점 마커 기록"
            setOnClickListener {
                DrivingAlertService.activeLogger?.marker("USER_MARKER")
                Toast.makeText(this@MainActivity, "마커를 기록했습니다.", Toast.LENGTH_SHORT).show()
            }
        })

        box.addView(section("지정 앱 정책"))
        box.addView(Button(this).apply { text = "지정 앱 선택 · DPI/출력 설정"; setOnClickListener { startActivity(Intent(this@MainActivity, AppPolicyActivity::class.java)) } })
        box.addView(Button(this).apply { text = "접근성 서비스 설정 열기"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        box.addView(TextView(this).apply {
            text = "DPI: 선택 앱이 전면에 있을 때 순정/140/120/수동값을 적용하고 벗어나면 wm density reset.\n다른 앱 오디오: 미디어는 기본 동작, 운전석 강제 라우팅은 BYD cross-UID 전용 훅 검증 전까지 '검증대기'로 표시합니다."
            textSize = 13f
        })

        val required = VoiceAssetCatalog.requiredAssetNames().size
        box.addView(section("상태"))
        box.addView(TextView(this).apply {
            text = "사전녹음 음성 슬롯: $required 개(남/여 + 좌/우 경고 포함)\nRAW 로그: 서비스 시작과 동시에 자동 수집, 버튼으로 Download ZIP 생성\n기어/EPB: 실차 확인 매핑 적용\n회생제동: AutoFeedback 참조값 2=STANDARD, 3=HIGH 적용\n그 외 원시신호: 추정 재생 금지, 캘리브레이션 로그 수집"
            textSize = 13f
        })
        return root
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, 24, 0, 8)
    }
}
