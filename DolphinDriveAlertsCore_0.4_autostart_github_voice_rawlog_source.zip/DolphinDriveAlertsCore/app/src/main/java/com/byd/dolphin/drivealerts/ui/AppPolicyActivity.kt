package com.byd.dolphin.drivealerts.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.byd.dolphin.drivealerts.dpi.*
import com.byd.dolphin.drivealerts.model.OutputRoute

class AppPolicyActivity : Activity() {
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,20,24,20) }
        root.addView(TextView(this).apply { text="지정 앱 · DPI/오디오 정책"; textSize=22f })
        root.addView(TextView(this).apply {
            text="여러 앱을 각각 지정할 수 있습니다. 항목을 눌러 순정/140/120/수동 DPI와 미디어/운전석 출력 정책을 저장합니다."
            textSize=13f; setPadding(0,6,0,12)
        })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val policies = AppPolicyStore.all(this)
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            val current = policies[pkg]
            val row = Button(this).apply {
                isAllCaps = false
                text = buildString {
                    append(if (current != null) "✓ " else "○ ")
                    append(ri.loadLabel(pm)); append("\n"); append(pkg)
                    if (current != null) append("\nDPI=${current.dpiMode}${if(current.dpiMode==DpiMode.MANUAL) "(${current.manualDpi})" else ""} · AUDIO=${current.audioRoute}")
                }
                setOnClickListener { edit(pkg, ri.loadLabel(pm).toString(), current) }
            }
            list.addView(row, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun edit(pkg: String, label: String, existing: AppPolicy?) {
        val outer = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(35,10,35,0) }
        val enabled = CheckBox(this).apply { text="이 앱에 정책 적용"; isChecked=existing!=null }
        outer.addView(enabled)
        outer.addView(TextView(this).apply { text="DPI" })
        val dpi = Spinner(this).apply {
            adapter=ArrayAdapter(this@AppPolicyActivity, android.R.layout.simple_spinner_dropdown_item, listOf("순정","140","120","수동"))
            setSelection(when(existing?.dpiMode){ DpiMode.DPI_140->1; DpiMode.DPI_120->2; DpiMode.MANUAL->3; else->0 })
        }
        outer.addView(dpi)
        val manual = EditText(this).apply {
            hint="수동 DPI (120~640)"; inputType=InputType.TYPE_CLASS_NUMBER
            setText((existing?.manualDpi ?: 160).toString())
        }
        outer.addView(manual)
        outer.addView(TextView(this).apply { text="오디오 출력 정책" })
        val audio = Spinner(this).apply {
            adapter=ArrayAdapter(this@AppPolicyActivity, android.R.layout.simple_spinner_dropdown_item, listOf("미디어 출력","운전석 출력 (검증대기)"))
            setSelection(if(existing?.audioRoute==OutputRoute.DRIVER_STREAM14) 1 else 0)
        }
        outer.addView(audio)
        AlertDialog.Builder(this).setTitle(label).setView(outer)
            .setPositiveButton("저장") { _, _ ->
                if (!enabled.isChecked) AppPolicyStore.remove(this, pkg)
                else {
                    val mode = when(dpi.selectedItemPosition){1->DpiMode.DPI_140;2->DpiMode.DPI_120;3->DpiMode.MANUAL;else->DpiMode.STOCK}
                    val value = manual.text.toString().toIntOrNull()?.coerceIn(120,640) ?: 160
                    val route = if(audio.selectedItemPosition==1) OutputRoute.DRIVER_STREAM14 else OutputRoute.MEDIA
                    AppPolicyStore.put(this, AppPolicy(pkg, mode, value, route))
                }
                refresh()
            }
            .setNegativeButton("취소", null).show()
    }
}
