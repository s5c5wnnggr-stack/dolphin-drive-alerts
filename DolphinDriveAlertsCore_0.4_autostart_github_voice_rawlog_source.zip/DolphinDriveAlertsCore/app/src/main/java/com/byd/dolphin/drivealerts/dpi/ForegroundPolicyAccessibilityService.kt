package com.byd.dolphin.drivealerts.dpi

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.byd.dolphin.drivealerts.util.CoreLog

class ForegroundPolicyAccessibilityService : AccessibilityService() {
    private var activePackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()?.takeIf { it.isNotBlank() } ?: return
        if (pkg == activePackage) return
        activePackage = pkg
        val policy = AppPolicyStore.all(this)[pkg]
        if (policy == null) {
            DensityController.apply(this, null)
            return
        }
        CoreLog.i("APP_POLICY", "foreground=$pkg dpi=${policy.dpiMode} audio=${policy.audioRoute}")
        DensityController.apply(this, policy.requestedDpi())
        ExternalAppAudioRouter.apply(this, pkg, policy.audioRoute)
    }

    override fun onInterrupt() = Unit
    override fun onDestroy() { DensityController.apply(this, null); super.onDestroy() }
}
