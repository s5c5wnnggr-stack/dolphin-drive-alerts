package com.byd.dolphin.drivealerts.audio

import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.AlertStyle
import com.byd.dolphin.drivealerts.model.Side

object VoiceAssetCatalog {
    fun path(request: AlertRequest, style: AlertStyle): String? {
        val folder = when (style) {
            AlertStyle.MALE -> "male"
            AlertStyle.FEMALE -> "female"
            AlertStyle.EFFECT -> return null
        }
        val base = request.event.name.lowercase()
        val suffix = when (request.side) {
            Side.LEFT -> "_left"
            Side.RIGHT -> "_right"
            Side.UNKNOWN -> ""
        }
        return "voice/$folder/$base$suffix.wav"
    }

    fun requiredAssetNames(): List<String> = buildList {
        for (style in listOf("male", "female")) {
            for (event in com.byd.dolphin.drivealerts.model.AlertEvent.entries) {
                val base = event.name.lowercase()
                add("voice/$style/$base.wav")
                if (event.name in setOf("BSD_WARNING", "LANE_DEPARTURE", "EXIT_REAR_WARNING")) {
                    add("voice/$style/${base}_left.wav")
                    add("voice/$style/${base}_right.wav")
                }
            }
        }
    }
}
