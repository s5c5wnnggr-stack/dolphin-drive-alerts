package com.byd.dolphin.drivealerts.log

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.byd.dolphin.drivealerts.util.CoreLog
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object DiagnosticsExporter {
    fun exportToDownloads(context: Context, logger: RawSignalLogger): Result<String> = runCatching {
        logger.flush()
        val name = "DolphinDriveAlerts_RAW_${stamp()}.zip"
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("MediaStore insert failed")
            try {
                resolver.openOutputStream(uri, "w")!!.use { out -> writeZip(context, logger, out) }
                values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0); resolver.update(uri, values, null, null)
            } catch (t: Throwable) {
                resolver.delete(uri, null, null); throw t
            }
            "Download/$name"
        } else {
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
            val outFile = File(dir, name)
            FileOutputStream(outFile).use { writeZip(context, logger, it) }
            outFile.absolutePath
        }
    }.onFailure { CoreLog.w("EXPORT", "failed: ${it.message}", it) }

    private fun writeZip(context: Context, logger: RawSignalLogger, rawOut: java.io.OutputStream) {
        ZipOutputStream(BufferedOutputStream(rawOut)).use { zip ->
            logger.directory().listFiles()?.filter { it.isFile }?.sortedBy { it.name }?.forEach { add(zip, it, "logs/${it.name}") }
            val meta = """{
  "app":"Dolphin Drive Alerts Core",
  "exportedAtMs":${System.currentTimeMillis()},
  "manufacturer":"${escape(Build.MANUFACTURER)}",
  "model":"${escape(Build.MODEL)}",
  "device":"${escape(Build.DEVICE)}",
  "product":"${escape(Build.PRODUCT)}",
  "sdk":${Build.VERSION.SDK_INT},
  "release":"${escape(Build.VERSION.RELEASE)}"
}
"""
            zip.putNextEntry(ZipEntry("device.json")); zip.write(meta.toByteArray(Charsets.UTF_8)); zip.closeEntry()
            val prefs = File(context.applicationInfo.dataDir, "shared_prefs")
            prefs.listFiles()?.filter { it.isFile && it.name.contains("drive", true) }?.forEach { add(zip, it, "prefs/${it.name}") }
        }
    }

    private fun add(zip: ZipOutputStream, f: File, path: String) {
        zip.putNextEntry(ZipEntry(path)); f.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
    }
    private fun escape(s: String?) = (s ?: "").replace("\\", "\\\\").replace("\"", "\\\"")
    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).apply { timeZone = TimeZone.getDefault() }.format(Date())
}
