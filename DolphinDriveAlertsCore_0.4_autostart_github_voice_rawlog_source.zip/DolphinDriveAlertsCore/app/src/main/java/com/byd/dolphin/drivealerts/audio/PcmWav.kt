package com.byd.dolphin.drivealerts.audio

import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class PcmWav(
    val sampleRate: Int,
    val channels: Int,
    val bitsPerSample: Int,
    val pcm16: ShortArray
)

object PcmWavReader {
    fun read(input: InputStream): PcmWav {
        val bytes = input.use { it.readBytes() }
        require(bytes.size >= 44) { "WAV too small" }
        require(String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF") { "Not RIFF" }
        require(String(bytes, 8, 4, Charsets.US_ASCII) == "WAVE") { "Not WAVE" }
        var pos = 12
        var format = 1
        var channels = 1
        var sampleRate = 44_100
        var bits = 16
        var dataStart = -1
        var dataSize = 0
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4, Charsets.US_ASCII)
            val size = leInt(bytes, pos + 4).coerceAtLeast(0)
            val body = pos + 8
            if (body + size > bytes.size) break
            when (id) {
                "fmt " -> if (size >= 16) {
                    format = leShort(bytes, body).toInt() and 0xffff
                    channels = leShort(bytes, body + 2).toInt() and 0xffff
                    sampleRate = leInt(bytes, body + 4)
                    bits = leShort(bytes, body + 14).toInt() and 0xffff
                }
                "data" -> { dataStart = body; dataSize = size; break }
            }
            pos = body + size + (size and 1)
        }
        require(format == 1) { "Only PCM WAV supported, format=$format" }
        require(bits == 16) { "Only PCM16 supported, bits=$bits" }
        require(channels in 1..2) { "Only mono/stereo supported, channels=$channels" }
        require(dataStart >= 0 && dataSize > 0) { "WAV data chunk missing" }
        val count = dataSize / 2
        val bb = ByteBuffer.wrap(bytes, dataStart, count * 2).order(ByteOrder.LITTLE_ENDIAN)
        val pcm = ShortArray(count)
        bb.asShortBuffer().get(pcm)
        return PcmWav(sampleRate, channels, bits, pcm)
    }

    private fun leShort(b: ByteArray, p: Int): Short =
        ((b[p].toInt() and 0xff) or ((b[p + 1].toInt() and 0xff) shl 8)).toShort()

    private fun leInt(b: ByteArray, p: Int): Int =
        (b[p].toInt() and 0xff) or ((b[p + 1].toInt() and 0xff) shl 8) or
            ((b[p + 2].toInt() and 0xff) shl 16) or ((b[p + 3].toInt() and 0xff) shl 24)
}
