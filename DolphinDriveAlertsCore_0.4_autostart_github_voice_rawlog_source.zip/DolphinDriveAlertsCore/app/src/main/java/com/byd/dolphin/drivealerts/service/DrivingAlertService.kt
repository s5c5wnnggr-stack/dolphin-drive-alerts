package com.byd.dolphin.drivealerts.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.byd.dolphin.drivealerts.audio.AlertAudioPlayer
import com.byd.dolphin.drivealerts.config.AlertPreferences
import com.byd.dolphin.drivealerts.model.AlertEvent
import com.byd.dolphin.drivealerts.model.AlertRequest
import com.byd.dolphin.drivealerts.model.Side
import com.byd.dolphin.drivealerts.log.RawSignalLogger
import com.byd.dolphin.drivealerts.log.ReadOnlySignalProbe
import com.byd.dolphin.drivealerts.ui.MainActivity
import com.byd.dolphin.drivealerts.util.CoreLog
import com.byd.dolphin.drivealerts.vehicle.AlertGate
import com.byd.dolphin.drivealerts.vehicle.BydVehicleReader
import com.byd.dolphin.drivealerts.vehicle.VehicleEventDetector
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class DrivingAlertService : Service() {
    private lateinit var audio: AlertAudioPlayer
    private lateinit var reader: BydVehicleReader
    private lateinit var gate: AlertGate
    private lateinit var detector: VehicleEventDetector
    private val executor = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "byd-signal-poller") }
    private var task: ScheduledFuture<*>? = null
    private var tick = 0L
    private lateinit var rawLogger: RawSignalLogger
    private lateinit var signalProbe: ReadOnlySignalProbe

    override fun onCreate() {
        super.onCreate()
        audio = AlertAudioPlayer(this)
        reader = BydVehicleReader(this)
        gate = AlertGate { if (AlertPreferences.isEnabled(this)) audio.play(it) }
        detector = VehicleEventDetector(gate::submit)
        rawLogger = RawSignalLogger(this)
        signalProbe = ReadOnlySignalProbe(this)
        activeLogger = rawLogger
        rawLogger.marker("SERVICE_STARTED")
        startForeground(NOTIFICATION_ID, notification())
        task = executor.scheduleAtFixedRate(::sampleSafely, 0, 150, TimeUnit.MILLISECONDS)
        CoreLog.i("SERVICE", "started")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TEST_ALERT) {
            val event = intent.getStringExtra(EXTRA_EVENT)?.let { runCatching { AlertEvent.valueOf(it) }.getOrNull() }
            val side = intent.getStringExtra(EXTRA_SIDE)?.let { runCatching { Side.valueOf(it) }.getOrNull() } ?: Side.UNKNOWN
            if (event != null) gate.submit(AlertRequest(event, side))
        }
        return START_STICKY
    }

    private fun sampleSafely() = runCatching {
        val frame = reader.readFrame()
        val currentTick = ++tick
        val energy = if (currentTick % 4L == 0L) reader.readReferenceEnergySignals() else emptyMap()
        val probe = if (currentTick % 7L == 0L) signalProbe.snapshot() else emptyMap()
        rawLogger.record(frame, energy, probe)
        detector.accept(frame, energy)
    }.onFailure { CoreLog.w("SERVICE", "sample failed: ${it.message}", it) }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Removing the UI task must not stop the vehicle monitor. START_STICKY requests Android
        // to recreate the foreground service if the process is reclaimed.
        rawLogger.marker("TASK_REMOVED_KEEP_SERVICE")
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        task?.cancel(true)
        executor.shutdownNow()
        rawLogger.marker("SERVICE_STOPPED")
        rawLogger.close()
        activeLogger = null
        audio.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(): Notification {
        val channelId = "drive_alert_core"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "주행 보조 알림", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("주행 보조 알림 작동 중")
            .setContentText("BYD 차량 신호 감시 · 로컬 사전녹음 오디오")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_TEST_ALERT = "com.byd.dolphin.drivealerts.TEST_ALERT"
        const val EXTRA_EVENT = "event"
        const val EXTRA_SIDE = "side"
        private const val NOTIFICATION_ID = 1414
        @Volatile var activeLogger: RawSignalLogger? = null
            private set

        fun start(context: Context) {
            val i = Intent(context, DrivingAlertService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
        fun test(context: Context, event: AlertEvent, side: Side = Side.UNKNOWN) {
            val i = Intent(context, DrivingAlertService::class.java).setAction(ACTION_TEST_ALERT)
                .putExtra(EXTRA_EVENT, event.name).putExtra(EXTRA_SIDE, side.name)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }
}
