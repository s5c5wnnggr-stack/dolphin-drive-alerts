package com.byd.dolphin.drivealerts.util

import android.util.Log

object CoreLog {
    private const val ROOT = "DriveAlerts"
    fun d(tag: String, msg: String) = Log.d("$ROOT/$tag", msg)
    fun i(tag: String, msg: String) = Log.i("$ROOT/$tag", msg)
    fun w(tag: String, msg: String, tr: Throwable? = null) = Log.w("$ROOT/$tag", msg, tr)
    fun e(tag: String, msg: String, tr: Throwable? = null) = Log.e("$ROOT/$tag", msg, tr)
}
