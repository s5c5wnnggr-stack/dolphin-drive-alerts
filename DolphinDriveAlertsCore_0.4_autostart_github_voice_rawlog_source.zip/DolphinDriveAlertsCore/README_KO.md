# Dolphin Drive Alerts Core 0.1

UI 완성 전에 주행 보조 알림 코어만 분리한 Android 10 / BYD DiLink 3용 독립 프로젝트입니다.
나중에 Dolphin Launcher V1에 모듈로 합칠 수 있도록 차량 신호, 이벤트 판정, 오디오, 앱 정책을 분리했습니다.

## 이번 범위

- 알림 출력: `DRIVER_STREAM14` / `MEDIA`
- 알림 형태: 남성 사전녹음 / 여성 사전녹음 / 효과음
- 이벤트: 기어 P/D/N/R, 회생제동 STANDARD/HIGH, ECO/NORMAL/SPORT, Snow ON/OFF,
  AutoHold ON/OFF + 체결/해제, EPB 체결/해제, ICC ON/OFF, BSD 좌/우,
  앞차 출발, 차선 이탈 좌/우, 정차 후 도어 열기 전 후측방 위험 좌/우
- 지정 앱 다중 정책 저장
- 지정 앱 전면 감지 시 DPI: 순정 / 140 / 120 / 수동(120~640)
- 지정 앱 오디오 정책: MEDIA는 즉시 사용, DRIVER는 BYD cross-UID vendor hook 검증 대기

## 검증된 경로와 보수적 처리

1. 운전석 알림은 회수된 v30.5 실차 결과와 동일하게 `AudioAttributes.setLegacyStreamType(14)`를 우선 사용하고,
   실패 시 deprecated `AudioTrack(streamType=14)`로 fallback 합니다.
2. 기어 raw 값 `0=N, 1=R, 2=D, 3=P`, EPB `1=해제, 3=체결`은 기존 실차 코드의 검증값을 사용합니다.
3. 사용자 제공 AutoFeedback APK 문자열에서 회생제동 `2=STANDARD, 3=HIGH`, 도로상태 `1=COMMON, 2=SNOW`,
   operation mode `1=SPORT OFF, 2=SPORT ON` 참조값을 확인했습니다. SPORT OFF만으로 ECO/NORMAL을 구분할 수 없어 추정하지 않습니다.
4. AVH, ICC, 실제 BSD 위험 발생, 차선 이탈 좌/우, 도어 열기 전 후측방 위험은 API는 읽되 raw 의미가 확정되기 전 자동 음성을 내지 않습니다.
   `DriveAlerts/CAL` 로그에 전환값을 남겨 1회 실차 캡처로 매핑할 수 있습니다.

## 사전녹음 음성

차량의 TTS 엔진이 없거나 초기화 실패해도 지연 없이 동작하도록 런타임 TTS를 사용하지 않습니다.
`app/src/main/assets/voice/male` 및 `female`에 PCM16 WAV 음성팩을 넣으면 메모리 캐시 후 AudioTrack으로 즉시 재생합니다.
음성팩이 아직 없는 항목은 효과음으로 fallback 하며 가짜 로봇 TTS를 사용하지 않습니다.

## 앱별 DPI

AccessibilityService가 현재 전면 앱을 감지하고, 선택된 앱이면 로컬 ADB `127.0.0.1:5555`를 통해 `wm density`를 적용합니다.
앱을 벗어나면 `wm density reset`으로 복원합니다. Android의 공개 API가 제공하는 진짜 per-app density가 아니라
"해당 앱이 전면인 동안 디스플레이 밀도를 자동 전환"하는 방식이므로 화면 재구성이 발생할 수 있습니다.

## 외부 앱 오디오 라우팅

일반 앱은 다른 UID가 재생하는 AudioTrack을 공개 Android API로 stream 14에 강제할 수 없습니다.
따라서 앱별 운전석 출력 선택값과 제어 인터페이스는 구현했지만 실제 적용은 `DRIVER_ROUTE_PENDING_VENDOR_HOOK` 상태로 남깁니다.
BYD vendor 명령/API가 실차에서 확인되면 `ExternalAppAudioRouter`만 교체하면 됩니다.


## CORE 0.2 추가
- 서비스 시작과 동시에 실차 RAW 신호 자동 로그 수집
- 150ms 핵심 폴링 + 1초 스냅샷 + 값 변경 즉시 기록
- BYD SDK parameter-free getter read-only 자동 탐색
- `수집된 파일 생성 · Download 폴더에 저장` 버튼으로 진단 ZIP 생성
- ZIP: `Download/DolphinDriveAlerts_RAW_yyyyMMdd_HHmmss.zip`
- 실차 조작 전후 비교용 `현재 시점 마커 기록` 버튼

## 음성팩
런타임 엔진은 남/여 58개 PCM WAV 슬롯을 모두 지원한다. 자연스러운 한국어 신규 음성 생성은 별도 음성 생성 수단이 필요하며, 검증되지 않은 로봇 음성이나 잘못된 문구를 임의로 넣지 않는다.

## 0.3: GitHub 음성 생성 + 실차 빌드

GitHub Actions `Build Real-Car APK with Korean Voice Pack`는 매 빌드마다 한국어 Neural TTS 음성을 새로 생성합니다.

- 남성: `ko-KR-InJoonNeural`
- 여성: `ko-KR-SunHiNeural`
- 각 29개, 총 58개 WAV
- 16-bit PCM / mono / 44.1kHz
- 차량에서는 온라인 TTS를 호출하지 않고 APK 내부 WAV를 즉시 재생합니다.
- Actions 산출물은 설치 가능한 debug-signed APK와, 실제 생성된 58개 음성이 포함된 전체 소스 ZIP입니다.

RAW 로그는 서비스 시작과 동시에 자동 수집되고 화면의 `수집된 파일 생성 · Download 폴더에 저장` 버튼으로 `Download/DolphinDriveAlerts_RAW_*.zip`을 생성합니다.
