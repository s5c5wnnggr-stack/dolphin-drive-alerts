# 자동 실행 / 백그라운드 동작

- 기본값: 활성화(true)
- 최초 설치 후 앱을 한 번 실행하면 foreground service가 즉시 시작됩니다.
- 이후 Android `BOOT_COMPLETED`, 표준/차량 Quick Boot 액션, `MY_PACKAGE_REPLACED`에서 서비스 자동 시작을 요청합니다.
- `DrivingAlertService`는 `START_STICKY`이며 `android:stopWithTask=false`로 구성했습니다. UI를 닫거나 최근 앱에서 제거해도 모니터링을 유지하도록 설계했습니다.
- foreground notification을 유지하여 Android 10 백그라운드 실행 제한에 맞춥니다.
- Android의 강제 종료(Force stop)는 시스템이 모든 receiver/service 재시작을 막는 특별 상태이므로, 사용자가 강제 종료한 경우에만 앱을 한 번 다시 실행해야 합니다.
- BYD 펌웨어가 서드파티 앱 자동실행을 별도로 차단하는 경우 실차 로그에서 확인해야 합니다.

실차 검증 포인트:
1. 앱 1회 실행 후 차량 재시동
2. 앱 화면을 열지 않고 notification/RAW 로그가 자동 생성되는지 확인
3. `Download` 내보내기 ZIP의 `SERVICE_STARTED` 및 BOOT 로그 확인
